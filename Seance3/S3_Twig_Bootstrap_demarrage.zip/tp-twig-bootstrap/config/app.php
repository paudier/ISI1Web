<?php
declare(strict_types=1);

// Configuration de l'application : un seul endroit pour les réglages.
// Lue par App\Config (src/Config.php).
return [
    // Nom affiché dans la barre de navigation et le pied de page
    'nom'           => 'Médiathèque',

    // Mode développement : cache recompilé automatiquement, dump(), erreur si variable inconnue.
    // À mettre à false en production.
    'debug'         => true,

    // false : Bootstrap est chargé depuis la copie locale (public/assets/vendor/), fonctionne hors ligne
    // true  : Bootstrap est chargé depuis le CDN jsDelivr (internet obligatoire)
    'bootstrap_cdn' => false,
];
