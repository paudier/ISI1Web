<?php
declare(strict_types=1);

namespace App;

/** Un livre du catalogue. Les propriétés publiques sont lisibles par Twig : {{ livre.titre }}. */
final readonly class Livre
{
    /** @param string[] $tags */
    public function __construct(
        public int $id,
        public string $titre,
        public string $auteur,
        public int $annee,
        public float $prix,
        public array $tags,
        public bool $disponible,
        public ?string $resume = null,
    ) {}

    /** Twig : {{ livre.classique }} appelle isClassique(). */
    public function isClassique(): bool
    {
        return $this->annee < 1900;
    }
}
