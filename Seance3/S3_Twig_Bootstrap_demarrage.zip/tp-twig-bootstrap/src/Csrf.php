<?php
declare(strict_types=1);

namespace App;

/** Jeton CSRF stocké en session (voir le complément de la séance 1). */
final class Csrf
{
    public static function token(): string
    {
        return $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
    }

    public static function verifier(?string $recu): bool
    {
        return is_string($recu)
            && isset($_SESSION['csrf'])
            && hash_equals($_SESSION['csrf'], $recu);
    }
}
