<?php
declare(strict_types=1);

namespace App;

use Twig\Environment;
use Twig\Extension\DebugExtension;
use Twig\Loader\FilesystemLoader;

final class TwigFactory
{
    /** @param bool|null $debug null : valeur du fichier config/app.php */
    public static function create(?bool $debug = null): Environment
    {
        $debug ??= (bool) Config::get('debug', false);
        $racine = dirname(__DIR__);

        $twig = new Environment(new FilesystemLoader($racine . '/templates'), [
            'cache'            => $racine . '/cache/twig', // false = pas de cache
            'debug'            => $debug,   // autorise {{ dump() }}
            'auto_reload'      => $debug,   // recompile si le .twig change
            'strict_variables' => $debug,   // variable inconnue = erreur
            'autoescape'       => 'html',   // (valeur par défaut)
        ]);

        if ($debug) {
            $twig->addExtension(new DebugExtension());
        }
        // Exercice 9 : enregistrer ici votre extension (AppExtension)
        $twig->addGlobal('app_nom', Config::get('nom', 'Application'));
        $twig->addGlobal('bootstrap_cdn', (bool) Config::get('bootstrap_cdn', false));

        return $twig;
    }
}
