<?php
declare(strict_types=1);

namespace App;

/** Catalogue en dur (pas de base de données dans cette séance). */
final class LivreRepository
{
    /** @return Livre[] */
    public function tous(): array
    {
        return [
            new Livre(1, 'Les Misérables', 'Victor Hugo', 1862, 12.5, ['roman', 'classique'], true,
                'Le destin de Jean Valjean dans la France du XIXe siècle.'),
            new Livre(2, 'Orgueil & Préjugés', 'Jane Austen', 1813, 9.9, ['roman', 'classique'], false),
            new Livre(3, 'Le Petit Prince', 'Antoine de Saint-Exupéry', 1943, 7.2, ['conte'], true,
                'Un aviateur rencontre un petit garçon venu d\'une autre planète.'),
            new Livre(4, 'Fondation', 'Isaac Asimov', 1951, 8.75, ['science-fiction'], true),
            new Livre(5, 'Clean Code', 'Robert C. Martin', 2008, 39.0, ['informatique'], true,
                'Écrire du code lisible et maintenable.'),
            new Livre(6, 'Dune', 'Frank Herbert', 1965, 11.0, ['science-fiction', 'roman'], false),
        ];
    }

    public function parId(int $id): ?Livre
    {
        foreach ($this->tous() as $livre) {
            if ($livre->id === $id) {
                return $livre;
            }
        }
        return null;
    }
}
