<?php
declare(strict_types=1);

namespace App;

/** Accès en lecture à la configuration (config/app.php). */
final class Config
{
    /** @var array<string, mixed>|null */
    private static ?array $valeurs = null;

    public static function get(string $cle, mixed $defaut = null): mixed
    {
        self::$valeurs ??= require dirname(__DIR__) . '/config/app.php';

        return array_key_exists($cle, self::$valeurs) ? self::$valeurs[$cle] : $defaut;
    }

    /** Remplace des valeurs en mémoire (utile pour les tests ; ne modifie pas le fichier). */
    public static function surcharger(array $valeurs): void
    {
        self::$valeurs = array_merge(self::$valeurs ?? require dirname(__DIR__) . '/config/app.php', $valeurs);
    }
}
