<?php
declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use App\Csrf;
use App\TwigFactory;

session_start();

const NIVEAUX = ['debutant' => 'Débutant', 'confirme' => 'Confirmé', 'expert' => 'Expert'];

$valeurs = [];
$erreurs = [];
$succes  = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::verifier($_POST['csrf'] ?? null)) {
        http_response_code(403);
        exit('Jeton CSRF invalide.');
    }

    $valeurs = [
        'nom'    => trim((string) ($_POST['nom'] ?? '')),
        'email'  => trim((string) ($_POST['email'] ?? '')),
        'niveau' => (string) ($_POST['niveau'] ?? ''),
    ];

    if ($valeurs['nom'] === '') {
        $erreurs['nom'] = 'Le nom est obligatoire.';
    }
    if (filter_var($valeurs['email'], FILTER_VALIDATE_EMAIL) === false) {
        $erreurs['email'] = 'Adresse e-mail invalide.';
    }
    if (!array_key_exists($valeurs['niveau'], NIVEAUX)) {
        $erreurs['niveau'] = 'Choisissez un niveau.';
    }

    $succes = $erreurs === [];
    if ($erreurs !== []) {
        http_response_code(422);
    }
}

echo TwigFactory::create()->render('inscription.html.twig', [
    'page'    => 'inscription',
    'valeurs' => $valeurs,
    'erreurs' => $erreurs,
    'niveaux' => NIVEAUX,
    'succes'  => $succes,
    'csrf'    => Csrf::token(),
]);
