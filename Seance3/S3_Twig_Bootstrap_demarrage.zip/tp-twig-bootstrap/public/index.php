<?php
declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use App\LivreRepository;
use App\TwigFactory;

$twig = TwigFactory::create();

$vue = ($_GET['vue'] ?? 'cartes') === 'tableau' ? 'tableau' : 'cartes';

echo $twig->render('livres/liste.html.twig', [
    'livres' => (new LivreRepository())->tous(),
    'page'   => 'liste',
    'vue'    => $vue,
]);
