<?php
declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use App\TwigFactory;

echo TwigFactory::create()->render('xss.html.twig', [
    'page' => 'xss',
    'q'    => (string) ($_GET['q'] ?? '<em>exemple</em>'),
]);
