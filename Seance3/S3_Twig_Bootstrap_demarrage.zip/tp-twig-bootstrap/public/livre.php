<?php
declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use App\LivreRepository;
use App\TwigFactory;

$twig  = TwigFactory::create();
$id    = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$livre = $id === false || $id === null ? null : (new LivreRepository())->parId($id);

if ($livre === null) {
    http_response_code(404);
    echo $twig->render('erreur.html.twig', ['code' => 404, 'message' => 'Livre introuvable.']);
    exit;
}

echo $twig->render('livres/detail.html.twig', ['livre' => $livre, 'page' => 'liste']);
